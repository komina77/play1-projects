package play.modules.slackappender;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Level;
import org.apache.log4j.spi.LoggingEvent;

import com.google.gson.Gson;

import play.libs.WS;

/**
 * @author https://github.com/oscasierra/sou4j-log4j
 */
public class SlackAppender extends AppenderSkeleton {

    private String webHookURL;

    public void setWebHookURL(String url) {
        this.webHookURL = url;
    }

    @Override
    public void close() { }

    @Override
    public boolean requiresLayout() {
        return true;
    }

    @Override
    protected void append(final LoggingEvent event) {
        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put("text", super.getLayout().format(event));

        try {
            this.sendMessage(parameters);
        }
        catch(IOException exception) {
            System.out.println(event.getMessage());
            exception.printStackTrace();
        }
    }

    /**
     * メッセージを送信します
     * @param parameters
     * @throws IOException
     */
    private void sendMessage(final Map<String, String> parameters) throws IOException {
        // 送信するPOSTデータを作成します
        String json = new Gson().toJson(parameters);
        try {
            WS.url(this.webHookURL).mimeType("application/json").body(json).post();

        } catch (NullPointerException e) {
            // WSの準備ができるまでは直接apiをたたく

            // URLConnectionを生成します
            URL url = new URL(this.webHookURL);
            URLConnection connection = url.openConnection();
            connection.setDoOutput(true);

            // リクエスト送信 & レスポンス取得
            PrintStream printStream = null;
            BufferedReader reader = null;
            try {
                printStream = new PrintStream(connection.getOutputStream());
                printStream.print("payload=");
                printStream.print(json);

                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                while(reader.readLine() != null) {}

            } finally {
                IOUtils.closeQuietly(printStream);
                IOUtils.closeQuietly(reader);
            }
        }

    }

}
